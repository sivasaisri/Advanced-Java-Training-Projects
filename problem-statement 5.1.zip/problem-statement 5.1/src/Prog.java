
public class Prog {

	public static void main(String[] args) {
	String s="JAVA is Simple";
	StringBuilder k=new StringBuilder(s);
	k.reverse();
	
	System.out.println(k);
		String res="";
	System.out.println(s.toUpperCase());
	System.out.println(s.toLowerCase());
	System.out.println(s.charAt(0));
	System.out.println(s.length());
	
	System.out.println(s.split(s));
//		for( int i=s.length()-1;i>=0;i--) {
//			res =res +s.charAt(i);
//		}
//			System.out.println(res);
			
			
		
	}
}