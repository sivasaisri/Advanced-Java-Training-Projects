import java.util.stream.IntStream;

public class Program {
	 public static void main (String[] args)
	    {        
//	      // declares an Array of integers.
//	      int[] arr;
//	         
//	      // allocating memory for 5 integers.
//	      arr = new int[18];
//	         
//	      // initialize the first elements of the array
//	     
//	      int arr1[] ={3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0,};
		 int[] arr;
         
	      // allocating memory for 5 integers.
	      arr = new int[18];
	         
	      // initialize the first elements of the array
	      arr[0] = 3;
	         
	      // initialize the second elements of the array
	      arr[1] = 2;
	         
	      //so on...
	      arr[2] = 4;
	      arr[3] = 5;
	      arr[4] = 6;
	      arr[5] = 4;
	      arr[6] = 5;
	      arr[7] = 7;
	      arr[8] = 3;
	      arr[9] = 2;
	      arr[10] = 3;
	      arr[11] = 4;
	      arr[12] = 7;
	      arr[13] = 1;
	      arr[14] = 2;
	      int sum = 0;
		arr[15] = sum;
	      arr[16] = 0;
	      arr[17]=0;
//	         
	      // accessing the elements of the specified array
	      for (int i = 0; i < arr.length; i++)
	         System.out.println("Element at index " + i +
	                                      " : "+ arr[i]);     
	      
	      sum= IntStream.of(arr[i]).sum();
	      //System.out.println("Element at index " + 
                 // " : "+ arr[15]);
	    //  System.out.println(arr[15]);
	      //System.out.println(sum);
	    }
}
