import java.util.Scanner;

public class RecProgram {
	 int length; 
	    int breadth; 
	    int area; 
	   
	    public RecProgram()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = in.nextInt();
	        System.out.print("Enter breadth of rectangle: ");
	        breadth = in.nextInt();
	    }

	    void calculate() {
	        area = length * breadth;
	        
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	       
	    }

	    public static void main(String args[]) {
	        RecProgram obj1 = new  RecProgram();
	        obj1.input();
	        obj1.calculate();
	        obj1.display();
	        System.out.println("****************************");
	        RecProgram obj2 = new  RecProgram();
	        obj2.input();
	        obj2.calculate();
	        obj2.display();
	        System.out.println("****************************");
	        RecProgram obj3 = new RecProgram();
	        obj3.input();
	        obj3.calculate();
	        obj3.display();
	        System.out.println("****************************");
	        RecProgram obj4 = new  RecProgram();
	        obj4.input();
	        obj4.calculate();
	        obj4.display();
	        System.out.println("****************************");
	        RecProgram obj5 = new  RecProgram();
	        obj5.input();
	        obj5.calculate();
	        obj5.display();
	    }
}
