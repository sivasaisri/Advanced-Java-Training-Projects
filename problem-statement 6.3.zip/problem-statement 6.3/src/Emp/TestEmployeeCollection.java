package Emp;

import java.util.Vector;

public class TestEmployeeCollection {
	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
		}

	private static Vector<Employee> addInput() {
	
		return null;
	}

	private static void display(Vector<Employee> v) {
		
}
}