
public class medicane1 {
	
		public void displayLabel()
	{
			System.out.println("Company : Globex Pharma");
	System.out.println("Address : Bangalore");}}
	class Tablet extends medicane1{
		public void displayLabel() 
		{System.out.println("store in a cool dry place");
		}
		}
	class Syrup extends medicane1{
			public void displayLabel(){ 
				System.out.println("Consumption as directed by thephysician");
				}
			}
	class Ointment extends medicane1
	{
		public void displayLabel(){System.out.println("for external use only");
	}
	}
	

